/** Automatically generated file. DO NOT MODIFY */
package jp.qr.java_conf.mogpuk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}